﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace service
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //servicio referencia

        private static ServiceReference1.WebService1Soap servicio = new ServiceReference1.WebService1SoapClient();
        private static ServiceReference2.WebService2Soap servicio2 = new ServiceReference2.WebService2SoapClient();
        private static ServiceReference3.WebService3Soap servicio3 = new ServiceReference3.WebService3SoapClient();

        private static ServiceReference4.WebService1Soap servicio4 = new ServiceReference4.WebService1SoapClient();
        void CargarDatos()
        {

       
        }


        public MainWindow()
        {
            InitializeComponent();
        }

        private void agregar1_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Listar1()
        {
            data2.ItemsSource = servicio.Listar().Tables[0].AsDataView();

        }
        private void Listar2()
        {
            data3.ItemsSource = servicio2.Listar().Tables[0].AsDataView();

        }
        private void Listar3()
        {
            data1.ItemsSource = servicio3.Listar().Tables[0].AsDataView();

        }
        private void agregar_Click(object sender, RoutedEventArgs e)
        {
            int job_id=Convert.ToInt16(txtid.Text.Trim());
            string job_desc = txtdesc.Text.Trim();
            int min_lvl = Convert.ToInt16(txtlvl.Text.Trim());
            int max_lvl = Convert.ToInt16(txtlvmax.Text.Trim());
            servicio3.Agregar(job_desc, min_lvl, max_lvl);
            Listar3();

        }

        private void actualizar_Click(object sender, RoutedEventArgs e)
        {
            int job_id = Convert.ToInt16(txtid.Text.Trim());
            string job_desc = txtdesc.Text.Trim();
            int min_lvl = Convert.ToInt16(txtlvl.Text.Trim());
            int max_lvl = Convert.ToInt16(txtlvmax.Text.Trim());
            servicio3.Actualizar(job_id, job_desc, min_lvl, max_lvl);
            Listar3();
        }

        private void eliminar_Click(object sender, RoutedEventArgs e)
        {
            int job_id = Convert.ToInt16(txtid.Text.Trim());
            servicio3.Eliminar(job_id);
            Listar3();
        }

        private void listar_Click(object sender, RoutedEventArgs e)
        {
            Listar3();
        }
      
        private void actualizar1_Click(object sender, RoutedEventArgs e)
        {
            string title_id = txtid.Text.Trim();
            int lorange = Convert.ToInt32(txtdesc.Text.Trim());
            int hirange = Convert.ToInt32(txtlvl.Text.Trim());
            int royalty = Convert.ToInt32(txtlvmax.Text.Trim());
            servicio.Actualizar(title_id, lorange, hirange, royalty);
            Listar1();
        }

        private void eliminar1_Click(object sender, RoutedEventArgs e)
        {
            string title_id = txtid.Text.Trim();
            servicio2.Eliminar(title_id);
            Listar2();
        }

        private void listar1_Click(object sender, RoutedEventArgs e)
        {
            Listar1();
        }

        private void agregar3_Click(object sender, RoutedEventArgs e)
        {
            string discounttype = txtdiscontype.Text.Trim();
            string stor_id = txtstoreid.Text.Trim();
            int lowqty = Convert.ToInt16(txtlowqt.Text.Trim());
            int hiqhqty = Convert.ToInt32(txthqt.Text.Trim());
            double discount = double.Parse(txtdiscount.Text.Trim());
            servicio2.Agregar(discounttype, stor_id, lowqty, hiqhqty, discount);
            Listar2();
            
        }

        private void actualizar3_Click(object sender, RoutedEventArgs e)
        {
            string discounttype = txtdiscontype.Text.Trim();
            string stor_id = txtstoreid.Text.Trim();
            int lowqty = Convert.ToInt16(txtlowqt.Text.Trim());
            int hiqhqty = Convert.ToInt32(txthqt.Text.Trim());
            double discount = double.Parse(txtdiscount.Text.Trim());
            servicio2.Actualizar(discounttype, stor_id, lowqty, hiqhqty, discount);
            Listar2();
        }

        private void eliminar3_Click(object sender, RoutedEventArgs e)
        {
            string discounttype = txtdiscontype.Text.Trim();
            servicio2.Eliminar(discounttype);
            Listar2();
        }

        private void listar3_Click(object sender, RoutedEventArgs e)
        {
            Listar2();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string title_id = txtid.Text.Trim();
            int lorange = Convert.ToInt32(txtdesc.Text.Trim());
            int hirange = Convert.ToInt32(txtlvl.Text.Trim());
            int royalty = Convert.ToInt32(txtlvmax.Text.Trim());
            servicio.Agregar(title_id, lorange, hirange, royalty);
            Listar1();


        }

        private void data1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
